Kilder:
- Alle bilder og videoer er hentet fra Pixabay
- Jeg har tatt inspirasjon, men gjort det til mitt eget, fra denne tutorialen: https://www.youtube.com/watch?v=R1S_NhKkvGA